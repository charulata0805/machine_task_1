<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class States extends CI_Controller {
	
	function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('states_model');
	}
	
	public function index(){
		$data['states'] = $this->states_model->getAllStates();
		$this->load->view('state_list',$data);
		//print_r($data);
		
	}
	public function delete($id){
		
		$query = $this->states_model->deletestate($id);

	    header('location:'.base_url().$this->index());
		
	}
	
	public function edit($id){
		$data['states'] = $this->states_model->getOneState($id);
		$this->load->view('edit_state', $data);
	}
	
	public function update($id){
		$state_name['state'] = $this->input->post('state');
		$query = $this->states_model->updatestatename($state_name, $id);
		
		header('location:'.base_url().$this->index());

	}
	public function addnewcity(){
		$data['states'] = $this->states_model->getAllStates();
		$this->load->view('addcity',$data);
		
		//print_r($data);
		
	}
	public function insert(){
		$cityname['city_name'] = $this->input->post('city_name');
		$cityname['state_id'] = $this->input->post('state_id');	
		$query = $this->states_model->insertcity($cityname);
		
		header('location:'.base_url().$this->index());

	}
	
	public function city_management(){
		$data['statecity'] = $this->states_model->getAllStatecity();
		$this->load->view('city_mana',$data);
		//print_r($data);
	     
	}
	public function deletecity($id){
		
		$query = $this->states_model->deletestatecity($id);

	    header('location:'.base_url().$this->index());
		
	}
	
	public function editcity($id){
		$data['statecity'] = $this->states_model->getcity($id);
		$this->load->view('edit_city', $data);
	}
}

?>