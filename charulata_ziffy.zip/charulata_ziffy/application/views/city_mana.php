<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>CodeIgniter Task</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>bootstrap/css/bootstrap.min.css">
</head>
<body>
<div class="container">
<div class="col-sm-8 col-sm-offset-2">
		<h1 class="page-header text-center">City Management</h1>
				<table class="table table-bordered table-striped">
				<thead>
					<tr>
					    
						<th>Sr.no</th>
						<th >State Name</th>
						<th >City Name</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
					<?php
					foreach($statecity as $stc){
						?>
						<tr>
							<td><?php echo $stc->id; ?></td>
							<td><?php echo $stc->state; ?></td>
							<td><?php echo $stc->city_name; ?></td>
							<td><a href="<?php echo base_url(); ?>index.php/states/editcity/<?php echo $stc->id; ?>"></span> Edit</a>  <a href="<?php echo base_url(); ?>index.php/states/deletecity/<?php echo $stc->id; ?>" ></span> Delete</a></td>
							
						</tr>
						<?php
					}
					?>
				</tbody>
			</table>
		</div>
</div>
	</div>
</div>
</body>
</html>		
		