<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>CodeIgniter Task</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>bootstrap/css/bootstrap.min.css">
</head>
<body>
<div class="container">
	<h1 class="page-header text-center">State Management</h1>
	<div class="row">
		<div class="col-sm-8 col-sm-offset-2">
			<a href="<?php echo base_url(); ?>index.php/states/addnewcity" class="btn btn-primary"><span class="glyphicon glyphicon-plus"></span> Add City</a><a href="<?php echo base_url(); ?>index.php/states/city_management" class="btn btn-primary">City Management</a><br><br>
				<table class="table table-bordered table-striped">
				<thead>
					<tr>
					    
						<th>Sr.no</th>
						<th >State</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
					<?php
					foreach($states as $st){
						?>
						<tr>
							<td><?php echo $st->id; ?></td>
							<td><?php echo $st->state; ?></td>
							<td><a href="<?php echo base_url(); ?>index.php/states/edit/<?php echo $st->id; ?>"></span> Edit</a>  <a href="<?php echo base_url(); ?>index.php/states/delete/<?php echo $st->id; ?>" ></span> Delete</a></td>
						</tr>
						<?php
					}
					?>
				</tbody>
			</table>
		</div>
		
	</div>
	</div>
</div>
</body>
</html>