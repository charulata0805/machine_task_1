<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>CodeIgniter Task</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>bootstrap/css/bootstrap.min.css">
</head>
<body>
<div class="container">
	<h1 class="page-header text-center">State Management</h1>
	<div class="row">
		<div class="col-sm-8 col-sm-offset-2">
			
			<form method="POST" action="<?php echo base_url(); ?>index.php/states/insert" >
			<table class="table table-bordered table-striped">
				<thead>
					<tr>
					    
						<th>Enter City Name</th>
						<th>Select State</th>
					</tr>
					<td><input type="text" class="form-control"  name="city_name" placeholder="enter city name"></td>
					<th >  
						  	<select class="form-control" name="state_id">
							<option value="">All</option>
					    <?php
					foreach($states as $st){
						?>
						<option value="<?php echo $st->id; ?>"><?php echo $st->state; ?></option>
						<?php
					}
					?>
					</select> 
                   </th>
				</thead>
				
			</table>
			<button type="submit" class="btn btn-primary"> Save</button>
			</form>
		</div>
	</div>
	</div>
</div>
</body>
</html>