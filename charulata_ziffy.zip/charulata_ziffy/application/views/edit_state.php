<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>CodeIgniter Task</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>bootstrap/css/bootstrap.min.css">
</head>
<body>
<div class="container">
	<h1 class="page-header text-center">State Management</h1>
	<div class="row">
		<div class="col-sm-8 col-sm-offset-2">

			<?php extract($states); ?>
			<form method="POST" action="<?php echo base_url(); ?>index.php/states/update/<?php echo $id; ?>">
				<div class="form-group">
					<label>States:</label>
					<input type="text" class="form-control" value="<?php echo $state; ?>" name="state">
				</div>
			
			</br>		
			  
			<button type="submit" class="btn btn-success"> Update</button>
			</form>
		</div>
	</div>
	</div>
</div>
</body>
</html>