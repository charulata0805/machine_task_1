<?php
	class States_model extends CI_Model {
		function __construct(){
			parent::__construct();
			$this->load->database();
		}
		
	public function getAllStates(){
			$query = $this->db->get('States');
			return $query->result(); 
		
		}
    public function deletestate($id){
			$this->db->where('states.id', $id);
			return $this->db->delete('states');
	}		
	
	public function getOneState($id){
			$query = $this->db->get_where('states',array('id'=>$id));
			return $query->row_array();
		}
		
		
	public function updatestatename($state_name, $id){
			$this->db->where('states.id', $id);
			return $this->db->update('states', $state_name);
		}	
		
	//insertcity
	public function insertcity($cityname){
			return $this->db->insert('citynames', $cityname);
	}
		
		
	public function getAllStatecity(){
		$query = $this->db->query('SELECT ci.id,st.state,ci.city_name
										FROM citynames ci
										join states  st 
										on(ci.state_id=st.id)');
         return $query->result(); 
		}	
		
	public function deletestatecity($id){
		$this->db->where('citynames.id', $id);
	    return $this->db->delete('citynames ');

    }
	
	//public function getcity($id){
		    
	//	}
}

?>		